<div class="incontent login">
<?php echo $message; ?>
</div>